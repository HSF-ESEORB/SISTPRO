import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
if (!process.env.GEMINI_API_KEY) {
  console.error("ERRO: GEMINI_API_KEY não configurada no ambiente.");
}

export interface Match {
  id: string;
  homeTeam: string;
  awayTeam: string;
  league: string;
  date: string;
  time: string;
  sport: "Futebol" | "Basquete" | "Vôlei" | "Tênis" | "Tênis de Mesa";
  isHighlight: boolean;
}

export interface Analysis {
  recentForm: string;
  h2h: string;
  homeAway: string;
  lineups: string;
  stats: string;
  odds: string;
  prediction: {
    market: string;
    probability: number;
    confidence: "Baixo" | "Médio" | "Alto";
  };
}

export async function fetchDailyMatches(dateContext: string): Promise<Match[]> {
  const prompt = `Você é um Analista Esportivo Profissional. 
Contexto temporal: ${dateContext}. 

Sua tarefa OBRIGATÓRIA é encontrar o maior número possível de jogos de destaque (mais de 20 jogos) que acontecem EXATAMENTE na data mencionada no contexto.
ATENÇÃO: Você deve listar APENAS jogos que ainda NÃO começaram ou estão para começar. Ignore resultados de ontem ou jogos já encerrados.
Foque em jogos que ocorrerão hoje, a partir de agora.

Utilize fontes em tempo real como Flashscore, 365Scores, OneFootball, ge, Soccerway e SofaScore via Google Search.

Esportes desejados: Futebol, Basquete, Vôlei, Tênis e Tênis de Mesa.

Campos obrigatórios no JSON: homeTeam, awayTeam, league, date, time, sport, isHighlight.
- 'date' deve ser a data do jogo (ex: "06/05/2026").
- 'time' deve ser o horário de Brasília (ex: "16:00").
- 'sport' deve ser: "Futebol", "Basquete", "Vôlei", "Tênis", "Tênis de Mesa".
- 'isHighlight' deve ser true para os jogos principais de grandes ligas.

Retorne APENAS o array JSON.`;

  const callAi = async (useSearch: boolean) => {
    try {
      return await ai.models.generateContent({
        model: "gemini-flash-latest",
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          tools: useSearch ? [{ googleSearch: {} }] : [],
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                homeTeam: { type: Type.STRING },
                awayTeam: { type: Type.STRING },
                league: { type: Type.STRING },
                date: { type: Type.STRING },
                time: { type: Type.STRING },
                sport: { type: Type.STRING },
                isHighlight: { type: Type.BOOLEAN },
              },
              required: ["homeTeam", "awayTeam", "league", "date", "time", "sport", "isHighlight"],
            },
          },
        }
      });
    } catch (err: any) {
      if (err.message?.includes("403") || err.message?.includes("permission")) {
        console.warn(`Gemini API Permission Denied (Search=${useSearch}):`, err);
      }
      throw err;
    }
  };

  try {
    let response;
    try {
      // First attempt with search
      response = await callAi(true);
    } catch (searchError) {
      console.warn("Busca Google falhou ou sem permissão, tentando sem busca:", searchError);
      // Fallback without search
      response = await callAi(false);
    }

    if (!response || !response.text) {
      throw new Error("Resposta vazia da IA.");
    }

    const data = JSON.parse(response.text.trim());
    return data.map((m: any, index: number) => ({
      ...m,
      id: `${m.sport}-${index}-${Date.now()}`
    }));
  } catch (e: any) {
    console.error("Erro fatal na busca de jogos:", e);
    throw e;
  }
}

export async function analyzeMatch(match: Match): Promise<Analysis> {
  const prompt = `Como um Analista Profissional de Apostas, realize uma análise PROFUNDA e EM TEMPO REAL para o jogo de HOJE:
Esporte: ${match.sport}
Confronto: ${match.homeTeam} x ${match.awayTeam}
Liga: ${match.league}
Data: ${match.date}
Horário: ${match.time}

Use a busca para validar desfalques, odds de mercado atuais e notícias recentes.
Siga rigorosamente estas seções:
1. Forma recente (últimos 5 jogos, tendências de gols/pontos)
2. Confronto direto (H2H)
3. Casa x Fora (desempenho mandante vs visitante)
4. Escalações / Condições (desfalques, lesões atualizadas)
5. Estatísticas (xG, finalizações, métricas específicas do esporte)
6. Odds (valor identificado vs odds atuais)
7. Palpite (Mercado, Probabilidade estimada em %, Nível de confiança: Baixo/Médio/Alto)

Retorne em formato JSON.`;

  const callAnalyze = async (useSearch: boolean) => {
    try {
      return await ai.models.generateContent({
        model: "gemini-flash-latest",
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          tools: useSearch ? [{ googleSearch: {} }] : [],
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              recentForm: { type: Type.STRING },
              h2h: { type: Type.STRING },
              homeAway: { type: Type.STRING },
              lineups: { type: Type.STRING },
              stats: { type: Type.STRING },
              odds: { type: Type.STRING },
              prediction: {
                type: Type.OBJECT,
                properties: {
                  market: { type: Type.STRING },
                  probability: { type: Type.NUMBER },
                  confidence: { type: Type.STRING, enum: ["Baixo", "Médio", "Alto"] },
                },
                required: ["market", "probability", "confidence"],
              },
            },
            required: ["recentForm", "h2h", "homeAway", "lineups", "stats", "odds", "prediction"],
          },
        }
      });
    } catch (err: any) {
      if (err.message?.includes("403")) {
        console.warn(`Analise Permission Denied (Search=${useSearch}):`, err);
      }
      throw err;
    }
  };

  try {
    let response;
    try {
      response = await callAnalyze(true);
    } catch (searchError) {
      console.warn("Busca na análise falhou, tentando sem busca:", searchError);
      response = await callAnalyze(false);
    }
    
    if (!response || !response.text) {
      throw new Error("Resposta de análise vazia.");
    }
    
    return JSON.parse(response.text.trim());
  } catch (e: any) {
    console.error(`Erro ao analisar ${match.homeTeam}:`, e);
    throw new Error(`Falha ao analisar o jogo ${match.homeTeam}.`);
  }
}
